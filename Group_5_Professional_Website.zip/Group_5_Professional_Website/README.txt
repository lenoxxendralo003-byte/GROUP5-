GROUP FIVE MINI WEBSITE PROJECT
================================

FILES
-----
index.html    Home page
gallery.html  Gallery page
blog.html     Blog page
contact.html  Contact form
style.css     Shared external stylesheet
script.js     Mobile navigation and form demonstration

HOW TO OPEN ON YOUR LAPTOP
--------------------------
1. Extract this ZIP file.
2. Open the extracted folder.
3. Double-click index.html to open the website in your browser.
4. Use the navigation menu to visit Home, Gallery, Blog and Contact.
5. An internet connection is needed for the Google Font and externally hosted gallery photographs.

HOW TO UPDATE YOUR GITHUB PAGES WEBSITE
---------------------------------------
1. Open your GitHub repository: Group-5-website.
2. Open the Code tab.
3. Upload the five website files (index.html, gallery.html, blog.html, contact.html, style.css, script.js).
4. If GitHub asks whether to replace existing files, confirm that you want to replace them.
5. Commit the changes to the main branch.
6. Wait for GitHub Pages to publish, then refresh your live website.

IMPORTANT CONTACT FORM NOTE
---------------------------
The contact form demonstrates required fields, radio buttons, checkboxes, a dropdown, a message area and browser-side validation. It does NOT send messages to an email address or save them to a server. A backend or form-processing service is needed for real message delivery.

BEFORE SUBMISSION
-----------------
- Check that your group name/number is correct.
- Replace sample wording with your own group details if required.
- Test all four navigation links.
- Test the contact form.
- Check the website on both a wide and narrow browser window.
