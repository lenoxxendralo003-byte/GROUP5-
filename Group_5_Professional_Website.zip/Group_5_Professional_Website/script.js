const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('.main-nav');

if (menuButton && navigation) {
  menuButton.addEventListener('click', () => {
    const isOpen = navigation.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
    menuButton.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
    menuButton.textContent = isOpen ? '×' : '☰';
  });
}

const contactForm = document.querySelector('#contactForm');
const formNotice = document.querySelector('#formNotice');

if (contactForm && formNotice) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!contactForm.reportValidity()) return;
    formNotice.textContent = 'Thank you! The form demonstration worked. No message was sent or stored.';
    formNotice.classList.add('success-message');
    contactForm.reset();
  });

  contactForm.addEventListener('reset', () => {
    formNotice.textContent = '* Required fields. This demonstration form does not send or store messages.';
    formNotice.classList.remove('success-message');
  });
}
